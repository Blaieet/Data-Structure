/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   triangle.h
 * Author: Albert
 *
 * Created on 1 de marzo de 2016, 16:34
 */

#ifndef TRIANGLE_H
#define TRIANGLE_H

class triangle {
public:
    triangle(float a, float b);
    float getAreaTriangle();
private:
    float amplada;
    float alcada;

};

#endif /* TRIANGLE_H */
