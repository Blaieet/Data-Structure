
/* 
 * File:   BalancedBST.h
 * Author: Blai Ras i Albert Morales
 *
 * Created on 5 / maig / 2016, 09:03
 */

#ifndef BALANCEDBST_H
#define BALANCEDBST_H

#include "BinarySearchTree.h"
#include <string>

using namespace std;

class BalancedBST : public BinarySearchTree {
public:
    BalancedBST(); //Constructor
    void insert(string clau, Position *node); //Metode que afegeix una paraula al arbre i l'arregla
    int heihgt(Position* node);
    
    void balance(); //Arregla l'arbre, es crida desde insert
    
private:
    
};

#endif /* BALANCEDBST_H */

