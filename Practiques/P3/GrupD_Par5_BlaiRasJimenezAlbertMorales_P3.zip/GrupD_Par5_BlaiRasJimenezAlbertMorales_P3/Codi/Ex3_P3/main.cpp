/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: blrasjim7.alumnes
 *
 * Created on 5 / maig / 2016, 08:37
 */

#include <cstdlib>
#include "BinarySearchTree.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    BinarySearchTree tree;
    cout << "primer insert" << endl;
    tree.insert("aaaa", tree.root());

    cout << "\nsegon insert" << endl;
    tree.insert("bbbb", tree.root());
    
    cout << "\ntercer insert" << endl;
    tree.insert("cccc", tree.root());
    
    cout << "\nPostorder:\n" << endl;
    tree.printPostorder(tree.root());
    
    cout << "\nInorder:\n"<< endl;
    tree.printInorder(tree.root());
    

    cout << "\n";
    
    return 0;
}

