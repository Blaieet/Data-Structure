/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   BalancedPosition.cpp
 * Author: blrasjim7.alumnes
 * 
 * Created on 5 / maig / 2016, 09:37
 */

#include "BalancedPosition.h"

BalancedPosition::BalancedPosition(string clau) : Position(clau){
    
}

int BalancedPosition::setAltura(){
    int hola = 10;
    return hola;
}

