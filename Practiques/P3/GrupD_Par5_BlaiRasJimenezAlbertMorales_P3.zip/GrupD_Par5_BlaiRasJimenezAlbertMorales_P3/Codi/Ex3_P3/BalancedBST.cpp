/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   BalancedBST.cpp
 * Author: blrasjim7.alumnes
 * 
 * Created on 5 / maig / 2016, 09:03
 */

#include "BalancedBST.h"

BalancedBST::BalancedBST() {
    
}



