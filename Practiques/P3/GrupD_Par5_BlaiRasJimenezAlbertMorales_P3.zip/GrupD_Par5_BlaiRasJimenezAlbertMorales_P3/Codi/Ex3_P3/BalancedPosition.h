/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   BalancedPosition.h
 * Author: blrasjim7.alumnes
 *
 * Created on 5 / maig / 2016, 09:37
 */

#ifndef BALANCEDPOSITION_H
#define BALANCEDPOSITION_H

#include "Position.h"

class BalancedPosition : public Position {
public:
    BalancedPosition(string clau);
    int setAltura();
private:
    int altura;
    
};

#endif /* BALANCEDPOSITION_H */

