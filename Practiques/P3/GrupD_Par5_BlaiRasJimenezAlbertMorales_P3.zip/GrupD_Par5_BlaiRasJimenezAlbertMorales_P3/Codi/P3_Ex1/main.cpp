
/* 
 * File:   main.cpp
 * Author: Blai Ras i Albert Morales
 *
 * Created on 21 / Abril / 2016, 09:26
 */

#include <cstdlib>
#include <string>

#include "BinarySearchTree.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    BinarySearchTree tree; //Inicialitzo un arbre nou
    
    cout << "Afegim 3 elements: 'bbbb', 'aaaa' i 'cccc'.\n";
    
    //Afegeixo, per exemple, 3 elements
    tree.insert("bbbb",tree.root());
    tree.insert("aaaa",tree.root());
    tree.insert("cccc",tree.root());
    
    cout << "L'arbre te un altura de " << tree.height(tree.root()) << "\n";
    
    cout << "Busco l'string 'cccc' (1: existeix, 0: no existeix): " << tree.search("cccc", tree.root()) << "\n";
    
    cout << "Imprimeixo l'arbe en Inordre\n";
    
    tree.printInorder(tree.root()); 
    cout << "\n";
    
    cout << "Imprimeixo l'arbre en Preordre\n";
            
    tree.printPreorder(tree.root());
    cout << "\n";
    
    cout << "Imprimeixo l'arbre en Postordre\n";
    
    tree.printPostorder(tree.root());
    
    cout << "\n";
    
    return 0;
}

