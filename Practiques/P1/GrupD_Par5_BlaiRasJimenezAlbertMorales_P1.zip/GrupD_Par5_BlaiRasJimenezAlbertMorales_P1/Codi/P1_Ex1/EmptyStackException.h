/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   EmptyStackException.h
 * Author: Albert
 *
 * Created on 15 de marzo de 2016, 14:41
 */

#ifndef EMPTYSTACKEXCEPTION_H
#define EMPTYSTACKEXCEPTION_H

class EmptyStackException {
public:
    EmptyStackException();
    const string error = "EmptyStackException \n";
private:
    
};

#endif /* EMPTYSTACKEXCEPTION_H */

