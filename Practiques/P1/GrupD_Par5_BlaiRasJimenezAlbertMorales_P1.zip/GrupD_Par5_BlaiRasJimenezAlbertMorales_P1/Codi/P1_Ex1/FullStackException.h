/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FullStackException.h
 * Author: Albert
 *
 * Created on 15 de marzo de 2016, 14:50
 */

#ifndef FULLSTACKEXCEPTION_H
#define FULLSTACKEXCEPTION_H
#include <string>

using namespace std;

class FullStackException {
public:
    FullStackException();
    const string error = "FullStackException \n";

private:

};

#endif /* FULLSTACKEXCEPTION_H */

